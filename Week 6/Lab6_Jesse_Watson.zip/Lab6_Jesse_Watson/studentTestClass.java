
class studentTestClass {
	public static void main (String[] args) {
	
		Student a1 = new Student();

			a1.setTuition(1);
			a1.setLecture(1);
			a1.setLabCost(1);
			a1.finalResult();

		Student a2 = new Student();
		
			a2.setTuition(2);
			a2.setLecture(2);
			a2.setLabCost(2);
			a2.finalResult();
			

			
	}
}