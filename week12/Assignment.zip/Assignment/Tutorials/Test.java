import javax.swing.JFrame;

class Test{
	public static void main(String[] args) {
	
	Tuna bucky = new Tuna();
	bucky.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	bucky.setSize(275,180);
	bucky.setVisible(true);
	
	}
}