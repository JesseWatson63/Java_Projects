public class outStateStudent extends Student {

	public double classCost = 400;
	
}