public class InStateStudent extends Student {

	public double classCost = 200;
	
}