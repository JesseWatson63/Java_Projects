public class Course {
	
	public int hours = 0;
	
	public void setHours(int classHours){
		hours = classHours;
	}
	
	public int getHours(){
		return hours;
	}

}