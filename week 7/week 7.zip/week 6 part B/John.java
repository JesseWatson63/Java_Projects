public class John extends Student{
	
	public int setUserInput() {
		return 10;
	}
	
}