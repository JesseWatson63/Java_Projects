class Test{
	public static void main (String[] args) {
	
		John a1 = new John();
			System.out.println("Your lab fee will be " + a1.setLabCost(0));
			System.out.println("Your Lecture hours will be " + a1.setLecture(1));
			System.out.println("Your tuition will be " + a1.setTuition(1));
			System.out.println("Your total cost will be: " + a1.getTotalCost());
			System.out.println(a1.getUserInput());
			System.out.println("--------------------------------------");
	
		John a2 = new John();
			System.out.println("Your lab fee will be " + a2.setLabCost(1));
			System.out.println("Your Lecture hours will be " + a2.setLecture(0));
			System.out.println("Your tuition will be " + a2.setTuition(0));
			System.out.println("Your total cost will be: " + a2.getTotalCost());
			System.out.println(a2.getUserInput());
			System.out.println("--------------------------------------");
	
		John a3 = new John();
			System.out.println("Your lab fee will be " + a3.setLabCost(0));
			System.out.println("Your Lecture hours will be " + a3.setLecture(1));
			System.out.println("Your tuition will be " + a3.setTuition(1));
			System.out.println("Your total cost will be: " + a3.getTotalCost());
			System.out.println(a3.getUserInput());
			System.out.println("--------------------------------------");
	

	}
}