class AutomobileTestDrive {
	public static void main (String[] args) {
	Automobile a = new Automobile();
	
	a.setMPG(30);
	a.setTankSize(10);
	a.setDistance(300);
	a.FinalResult();
	
	
	Automobile a2 = new Automobile();
	a2.setMPG(22);
	a2.setTankSize(15);
	a2.setDistance(300);
	a2.FinalResult();
	
	
	}
}