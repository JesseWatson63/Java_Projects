public class Test {
	public static void main (String[] arg){

		RPS player1 = new RPS();
		RPS player2 = new RPS();

		player1.setPlayerName("Bill Gates");
		player2.setPlayerName("Steve Jobs");
		System.out.println(player1.getPlayerName() + " VS. " + player2.getPlayerName() );
		System.out.println();
		
		Game round1 = new Game();
		System.out.println("Round 1");
		System.out.println(round1.getRoundResult());
		System.out.println(round1.getGameResult());
		System.out.println("");
		
		Game round2 = new Game();
		System.out.println("Round 2");
		System.out.println(round2.getRoundResult());
		System.out.println(round2.getGameResult());
		System.out.println("");
		
		Game round3 = new Game();
		System.out.println("Round 3");
		System.out.println(round3.getRoundResult());
		System.out.println(round3.getGameResult());
		System.out.println("");
		System.out.println("");
		System.out.println("");

	}
}