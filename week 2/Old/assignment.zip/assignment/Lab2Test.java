class Lab2Test {
	public static void main (String[] args) {
	
		Lab2 a=new Lab2();
		
		a.rectangleTest();
		System.out.println("......................");
		a.rectangleTest2();
	}
}