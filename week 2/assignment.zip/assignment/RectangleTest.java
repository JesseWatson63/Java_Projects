public class RectangleTest{

	public static void main (String[] args){
		System.out.println("test 1");
		Rectangle r = new Rectangle();
		r.MakeRectangle();
		
		System.out.println("...........................");
		System.out.println("test 2");
	
		Rectangle r2 = new Rectangle();
		r2.MakeRectangle();
		
		System.out.println("...........................");
		System.out.println("test 3");
	
		Rectangle r3 = new Rectangle();
		r3.MakeRectangle();
	}
	

}