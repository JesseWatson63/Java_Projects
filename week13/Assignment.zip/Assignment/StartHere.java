public class StartHere {
	public static void main(String arg[]) {
		
		FirstWindow fw = new FirstWindow();
		fw.setVisible(true);
		
	}
}